Installation:

1) This program was created on a Linux environment. For testing purposes,
	please install only on a UNIX/Linux machine.
2) Please make sure that (at least) Java 7 framework is installed
3) Extract the archive to a location where the current user has read/write access

How to run the HTTP log monitoring program:

1) From a UNIX terminal, 'cd' to the location of the unzipped files
2) Execute command to compile the program and test fixture:
   
	javac -cp .:junit-4.12.jar HttpLogMonitor*.java
	
3) Execute command to run test fixture to ensure basic tests will pass:

	java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar -ea org.junit.runner.JUnitCore HttpLogMonitorTest
	
4) Execute command to start the program:

	java -cp . -ea HttpLogMonitor logFile checkFrequency trafficWindow highTrafficThreshold
	
   Parameters:
   logFile - full path of log
   checkFrequency - the interval used by the program to analyze traffic (in seconds);
   	in the programming assigment, this value is 10 secs
   trafficWindow - the time window that is used by the program for high traffic 
   	alerts (in minutes); in the programing assignment, this value is 2 mins
   highTrafficThreshold - the limit to be breached by the traffic to trigger
   	an alert
   	
   e.g. java -cp . -ea HttpLogMonitor /home/user1/test.log 10 2 100
