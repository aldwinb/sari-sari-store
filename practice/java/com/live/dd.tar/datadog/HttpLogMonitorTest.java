package com.live.datadog;

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class HttpLogMonitorTest {

    @BeforeClass
    public static void fixtureSetUp() {
    }

    @AfterClass
    public static void fixtureTearDown() {
    }

    @Test(expected=FileNotFoundException.class)
    public void shouldThrowFileNotFoundException() throws Exception {
        // arrange
        // act
        HttpLogMonitor m = new HttpLogMonitor("xxxtestxxx.log"); 
        // assert
    }

    @Test
    public void canReadFromLastLine() throws Exception {
        // arrange
        String log = "lastLine.log",
               fields = HttpLogMonitor.FIELDS_DIRECTIVE + " date time s-ip " + 
                   "cs-method cs-uri-stem cs-uri-query s-port cs-username " +
                   "c-ip cs(User-Agent) sc-status sc-substatus " +
                   "sc-win32-status time-taken",
            line1 = "2014-11-07 13:50:39 10.3.5.115 " +
                "GET / - 80 - 10.3.5.114 - 500 0 0 7940 ",
            line2 = "2014-11-07 13:50:39 10.3.5.115 " +
                "OPTIONS / - 80 - 10.3.5.114 - 500 0 0 0 ",
            line3 = "2014-11-07 13:50:39 10.3.5.115 " +
                "PROPFIND / - 80 - 10.3.5.114 - 500 0 0 0 ",
            line4 = "2014-11-07 13:50:39 10.3.5.115 " +
                "OPTIONS * - 80 - 10.3.5.114 - 400 0 2148734208 15 ";
        Path p = Paths.get(log);
        
        // act
        Files.deleteIfExists(p);
        Files.write(p, (fields+"\n").getBytes());
        Files.write(p, (line1+"\n").getBytes(), StandardOpenOption.APPEND);
        HttpLogMonitor m = new HttpLogMonitor(log);
        m.read();
        Files.write(p, (line2+"\n").getBytes(), StandardOpenOption.APPEND);
        List<String> entries1 = m.read();
        Files.write(p, (line3+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line4+"\n").getBytes(), StandardOpenOption.APPEND);
        List<String> entries2 = m.read();
        Files.deleteIfExists(p);
        
        // assert
        assertEquals(1, entries1.size());
        assertEquals(line2, entries1.get(0));
        assertEquals(2, entries2.size());
        assertEquals(line3, entries2.get(0));
        assertEquals(line4, entries2.get(1));
    }

    @Test
    public void canGetMostHits() throws IOException {
        // arrange
        String log = "mostHits.log",
               fields = HttpLogMonitor.FIELDS_DIRECTIVE + " date time s-ip " + 
                   "cs-method cs-uri-stem cs-uri-query s-port cs-username " +
                   "c-ip cs(User-Agent) sc-status sc-substatus " +
                   "sc-win32-status time-taken",
            line1 = "2014-11-07 13:50:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line2 = "2014-11-07 13:50:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line3 = "2014-11-07 13:50:39 10.3.5.115 GET " +
                "/ - 80 - 10.3.5.114 - 500 0 0 0 ",
            line4 = "2014-11-07 13:50:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 31 ",
            line5 = "2014-11-07 13:50:43 10.3.5.115 GET " +
                "/console/faces/com_sun_web_ui/jsp/version/version_30.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 15 ",
            line6 = "2014-11-07 13:50:43 10.3.5.115 GET " +
                "/console/faces/com_sun_web_ui/jsp/version/version_4.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 0 ",
            mostUrl1 = "/owa",
            mostUrl2 = "/console";
        int mostCount2 = 2,
            mostCount1 = 3;

        Path p = Paths.get(log);
        
        // act
        Files.deleteIfExists(p);
        Files.write(p, (fields+"\n").getBytes());
        Files.write(p, (line1+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line2+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line3+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line4+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line5+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line6+"\n").getBytes(), StandardOpenOption.APPEND);
        HttpLogMonitor m = new HttpLogMonitor(log);
        m.analyze(Calendar.getInstance());
        Section[] mostHits = m.mostHits(2);
        Files.deleteIfExists(p);

        // assert
        assertEquals(2, mostHits.length);
        Section s1 = mostHits[0],
            s2 = mostHits[1];
        assertEquals(mostUrl1, s1.uri);
        assertEquals(mostCount1, s1.hits);
        assertEquals(mostUrl2, s2.uri);
        assertEquals(mostCount2, s2.hits);
    }

    @Test
    public void canTriggerAlertOnHighTraffic() throws IOException {
        // arrange
        String log = "highAlert.log",
                fields = HttpLogMonitor.FIELDS_DIRECTIVE + " date time s-ip " + 
                    "cs-method cs-uri-stem cs-uri-query s-port cs-username " +
                    "c-ip cs(User-Agent) sc-status sc-substatus " +
                    "sc-win32-status time-taken",
            line1 = "2014-11-07 13:50:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line2 = "2014-11-07 13:51:00 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line3 = "2014-11-07 13:51:00 10.3.5.115 GET " +
                "/owa/auth - 80 - 10.3.5.114 - 500 0 0 0 ",
            line4 = "2014-11-07 13:51:00 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 31 ",
            line5 = "2014-11-07 13:51:12 10.3.5.115 GET " +
                "/owa/faces/com_sun_web_ui/jsp/version/version_30.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 15 ",
            line6 = "2014-11-07 13:51:12 10.3.5.115 GET " +
                "/console/faces/com_sun_web_ui/jsp/version/version_4.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 0 ";

        Path p = Paths.get(log);
        Calendar d1 = Calendar.getInstance();
        d1.clear();
        d1.set(2014, 11, 7, 13, 50, 30);
        
        int window = 2,
            htThres = 4;

        // act
        Files.deleteIfExists(p);
        Files.write(p, (fields+"\n").getBytes());
        Files.write(p, (line1+"\n").getBytes(), StandardOpenOption.APPEND);
        HttpLogMonitor m = new HttpLogMonitor(log, window, htThres);
        m.analyze(d1);
        String htMsg1 = m.highTrafficAlert(); 
        Files.write(p, (line2+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line3+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line4+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line5+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line6+"\n").getBytes(), StandardOpenOption.APPEND);
        d1.add(Calendar.MINUTE, 51);
        m.analyze(d1);
        String htMsg2 = m.highTrafficAlert();
        Files.deleteIfExists(p);

        // assert
        assertTrue(htMsg1.length() == 0);
        assertTrue(htMsg2.length() > 0);
    }

    @Test
    public void canRecoverFromAHighTrafficAlert() throws IOException {
        // arrange
        String log = "normalTraffic.log",
                fields = HttpLogMonitor.FIELDS_DIRECTIVE + " date time s-ip " + 
                    "cs-method cs-uri-stem cs-uri-query s-port cs-username " +
                    "c-ip cs(User-Agent) sc-status sc-substatus " +
                    "sc-win32-status time-taken",
            line1 = "2014-11-07 23:58:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line2 = "2014-11-07 23:58:39 10.3.5.115 GET " +
                "/owa/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 0 ",
            line3 = "2014-11-07 23:58:39 10.3.5.115 GET " +
                "/owa/auth - 80 - 10.3.5.114 - 500 0 0 0 ",
            line4 = "2014-11-07 23:58:39 10.3.5.115 GET " +
                "/console/auth/logon.aspx - 80 - 10.3.5.114 Mozilla/5.0+" +
                "(compatible;+MSIE+7.0;+Windows+NT+6.0;+.NET+CLR+1.1.4322;+" +
                ".NET+CLR+2.0.50727) 500 0 0 31 ",
            line5 = "2014-11-07 23:58:42 10.3.5.115 GET " +
                "/console/faces/com_sun_web_ui/jsp/version/version_30.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 15 ",
            line6 = "2014-11-07 23:59:43 10.3.5.115 GET " +
                "/console/faces/com_sun_web_ui/jsp/version/version_4.jsp " +
                "- 80 - 10.3.5.114 Sun+Web+Console+Fingerprinter/7.15 500 " +
                "0 0 0 ",
            line7 = "2014-11-07 23:59:49 10.3.5.115 POST " +
                "/owa/xmlrpc/xmlrpc.php - 80 - 10.3.5.114 - 404 0 2 15 ",
            line8 = "2014-11-07 23:59:49 10.3.5.115 POST " +
                "/console/script/xmlrpc.php - 80 - 10.3.5.114 - 404 0 2 0 ",
            line9 = "2014-11-08 00:00:32 10.3.5.115 GET " +
                "/console/phpmyadmin/ - 80 - 10.3.5.114 - 500 0 0 0 ",
            line10 = "2014-11-08 00:00:33 10.3.5.115 GET " +
                "/console/README.txt - 80 - 10.3.5.114 - 404 0 2 0 ";

        Path p = Paths.get(log);
        Calendar d1 = Calendar.getInstance();
        d1.clear();
        d1.set(2014, 11, 7, 23, 58, 50);
        
        int window = 2,
            htThres = 5;

        // act
        Files.deleteIfExists(p);
        Files.write(p, (fields+"\n").getBytes());
        Files.write(p, (line1+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line2+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line3+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line4+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line5+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line6+"\n").getBytes(), StandardOpenOption.APPEND);
        HttpLogMonitor m = new HttpLogMonitor(log, window, htThres);
        m.analyze(d1);
        Files.write(p, (line7+"\n").getBytes(), StandardOpenOption.APPEND);
        Files.write(p, (line8+"\n").getBytes(), StandardOpenOption.APPEND);
        d1.add(Calendar.MINUTE, 1);
        m.analyze(d1);
        Files.write(p, (line9+"\n").getBytes(), StandardOpenOption.APPEND);
        d1.add(Calendar.MINUTE, 1);
        m.analyze(d1);
        String htMsg1 = m.highTrafficAlert(),
               ntMsg1 = m.recoveryAlert();
        Files.write(p, (line10+"\n").getBytes(), StandardOpenOption.APPEND);
        d1.add(Calendar.MINUTE, 1);
        m.analyze(d1);
        String htMsg2 = m.highTrafficAlert(),
               ntMsg2 = m.recoveryAlert();
        Files.deleteIfExists(p);

        // assert
        assertTrue(htMsg1.length() > 0);
        assertTrue(ntMsg1.length() == 0);
        assertTrue(htMsg2.length() == 0);
        assertTrue(ntMsg2.length() > 0);
    }

}
