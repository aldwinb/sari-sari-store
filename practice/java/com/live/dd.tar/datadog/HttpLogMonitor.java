package com.live.datadog;

import java.io.*;
import java.nio.file.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class HttpLogMonitor {

    private class MaxSectionComparator implements Comparator<Section> {
        public int compare(Section s1, Section s2) {
            if (s1.hits < s2.hits) return 1;
            return s1.hits > s2.hits ? -1 : 0;
        }
    }

    private class UriCount {
        public int total;
        public Map<String, Integer> byUri;
        public UriCount(int total, Map<String, Integer> byUri) {
            this.total = total;
            this.byUri = byUri;
        }
    }

    /* ======================================================================
     * =                             Fields                                 =
     * ======================================================================
     */
    private int currPos, uriIdx, tWindow, htThres, currTraffic;
    private String log, htAlert, recAlert;
    private Pattern uriPattern;
    private SimpleDateFormat df;
    private Map<String, Integer> fieldIdxs;
    private Map<String, Section> uris;
    private SortedMap<Long, Integer> trafficByTime; 
    private Queue<Section> maxUris;
    private static final String URI_PATTERN = "^(?:[a-zA-Z]+\\:\\/\\/" +
        "[^\\/]+?)?(\\/(?:[^\\/]*)).*$";
    private static final String URI_FIELD = "cs-uri";
    private static final String URI_STEM_FIELD = "cs-uri-stem";
    private static final int DEFAULT_TRAFFIC_WINDOW = 2;
    private static final int DEFAULT_HIGH_TRAFFIC_THRESHOLD = 100;
    
    public static final String DIRECTIVE_PREFIX = "#";
    public static final String FIELDS_DIRECTIVE = "#Fields:";


    /* ======================================================================
     * =                          Constructor                               =
     * ======================================================================
     */
    public HttpLogMonitor(String log) throws IOException, AssertionError { 
        if (!Files.exists(Paths.get(log)))
            throw new FileNotFoundException("log file not found");
        this.log = log;
        this.currPos = 0;
        htAlert = "";
        recAlert = "";
        df = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss ms");
        fieldIdxs = getFieldIdxs(log);
        uriIdx = getUriIdx(fieldIdxs);
        uriPattern = Pattern.compile(URI_PATTERN);
        tWindow = DEFAULT_TRAFFIC_WINDOW;
        htThres = DEFAULT_HIGH_TRAFFIC_THRESHOLD;
        uris = new HashMap<String, Section>();
        trafficByTime = new TreeMap<Long, Integer>();
        maxUris = new PriorityQueue<Section>(1, new MaxSectionComparator());
    }

    public HttpLogMonitor(String log, int tWindow, int htThres) 
        throws IOException, AssertionError { 
        this(log);
        this.tWindow = tWindow;
        this.htThres = htThres;
    }


    /* ======================================================================
     * =                         Public Methods                             =
     * ======================================================================
     */
    public void analyze(Calendar newTime) {
        List<Section> sections = new ArrayList<Section>();
        List<String> latest = null;
        try {
            latest = read();
        } catch (IOException ex) {
            System.out.format("Can't read log file: %s\n", ex.toString());
            return;
        }
        
        Calendar expTime = expiredTime(newTime, this.tWindow);
        addOrUpdSections(latest, 
                newTime.getTimeInMillis(), 
                expiredKey(expTime));
        this.recAlert = "";
        if (this.currTraffic > this.htThres)
            setHighTrafficAlert(this.currTraffic, newTime);
        else
            setRecoveryAlert(this.currTraffic, newTime);
    }

    public List<String> read() throws IOException {
        List<String> entries = new ArrayList<String>();
        int numChars = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(log))) {
            reader.skip(this.currPos);
            String line;
            while ((line = reader.readLine()) != null) {
                entries.add(line);
                numChars += line.length()+1;
            }
        } 

        this.currPos += numChars;
        return entries;
    }

    public Section[] mostHits(int top) {
        Section[] sections = new Section[Math.min(top, this.maxUris.size())];
        int i = 0;
        for (Section s : this.maxUris) {
            sections[i++] = s;
            if (i == top) break;
        }
        return sections;
    }

    public String highTrafficAlert() {
        return htAlert;
    }

    public String recoveryAlert() {
        return recAlert;
    }

    public void printMostHits(Section[] mostHits) {
        for (Section s : mostHits)
            System.out.format("%s\t%s hits\n", s.uri, s.hits);
    }


    /* ======================================================================
     * =                        Private Methods                             =
     * ======================================================================
     */
    private void addOrUpdSections(
            List<String> latest,
            long newTimeKey,
            long expTimeKey) {
        
        UriCount uc = countNewUris(latest);
        trafficByTime.put(newTimeKey, uc.total);
        int expCount = trafficByTime.containsKey(expTimeKey) 
            ? trafficByTime.remove(expTimeKey)
            : 0;

        for (String uri : uc.byUri.keySet()) {
            if (!this.uris.containsKey(uri)) {
                Section s = new Section(uri, uc.byUri.get(uri));
                this.uris.put(uri, s);
                this.maxUris.add(s); 
            } else {
                Section s = this.uris.get(uri);
                this.maxUris.remove(s);
                s.hits += uc.byUri.get(uri);
                this.maxUris.add(s);
            }
        }

        this.currTraffic -= (expCount - uc.total);
    }

    private void setHighTrafficAlert(int hits, Calendar newTime) {
        if (htAlert.length() == 0)
            htAlert = String.format("High traffic generated an alert - " +
                "hits = %s, triggered at %s", 
                hits, 
                df.format(newTime.getTime()));
    }

    private void setRecoveryAlert(int hits, Calendar newTime) {
        if (htAlert.length() > 0) {
            htAlert = "";
            recAlert = String.format("Traffic back to normal - hits = %s" +
                ", recovered at %s",
                hits, 
                df.format(newTime.getTime()));
        }
    }

    private long expiredKey(Calendar expTime) {
        if (this.trafficByTime.size() == 0) return 0;
        long expTimeInMillis = expTime.getTimeInMillis(),
             firstTime = this.trafficByTime.firstKey();
        return firstTime < expTimeInMillis ? firstTime : 0;
    }

    private Calendar expiredTime(Calendar newTime, int tWindow) {
        Calendar expire = Calendar.getInstance();
        expire.clear();
        expire.setTime(newTime.getTime());
        expire.add(Calendar.MINUTE, -tWindow);
        return expire;
    }

    private UriCount countNewUris(List<String> latest) {
        Map<String, Integer> uriCounts = new HashMap<String, Integer>();
        int total = 0;
        for (String e : latest) {
            String[] fields = e.split(" ");
            if (fields.length < 10) continue;
            String uri = fields[this.uriIdx];
            Matcher m = uriPattern.matcher(uri);
            if (!m.matches()) continue;
            uri = m.group(1);
            if (!uriCounts.containsKey(uri))
                uriCounts.put(uri, 1);
            else
                uriCounts.put(uri, uriCounts.remove(uri)+1);
            total++;
        }

        return new UriCount(total, uriCounts); 
    }

    private int getUriIdx(Map<String, Integer> fieldIdxs) {
        return fieldIdxs.containsKey(URI_FIELD) 
            ? fieldIdxs.get(URI_FIELD)
            : fieldIdxs.get(URI_STEM_FIELD);
    }

    private Map<String, Integer> getFieldIdxs(String log) 
        throws IOException, AssertionError {
        Map<String, Integer> fieldIdxs = null;
        int numChars = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(log))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(DIRECTIVE_PREFIX)) break;
                if (line.toLowerCase()
                        .startsWith(FIELDS_DIRECTIVE.toLowerCase()))
                    fieldIdxs = getFieldIdxsFromLine(
                            line.substring(FIELDS_DIRECTIVE.length()+1));
                numChars += line.length()+1;
            }
        }

        this.currPos += numChars;
        assert fieldIdxs != null && fieldIdxs.size() > 0;
        assert fieldIdxs.containsKey(URI_FIELD) 
            || fieldIdxs.containsKey(URI_STEM_FIELD);
        
        return fieldIdxs;
    }

    private Map<String, Integer> getFieldIdxsFromLine(String fieldLine) {
        final String[] fieldsToSearch = new String[] {
            "date",
            "time",
            "time-taken",
            "cs-uri",
            "cs-uri-stem",
            "cs-uri-query" };
        String[] names = fieldLine.trim().split(" ");
        Map<String, Integer> fieldIdxs = new HashMap<String, Integer>();
        for (String f : fieldsToSearch) {
            for (int i = 0; i < names.length; i++) {
                if (f.equals(names[i].trim()))
                    fieldIdxs.put(f, i);
            }
        }
        return fieldIdxs;
    }


    /* ======================================================================
     * =                               Main                                 =
     * ======================================================================
     */
    public static void main(String[] args) {
        String log = args[0];
        int sleep = Integer.parseInt(args[1]),
            tWindow = Integer.parseInt(args[2]),
            htThres = Integer.parseInt(args[3]);

        SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss ms");
        HttpLogMonitor m = null;
        try {
            m = new HttpLogMonitor(log, tWindow, htThres);
        } catch (IOException ex) {
            System.out.format("[%s] Error occurred while starting the " +
                    "program: %s", formattedTime(df), ex.toString());
            return;
        }

        System.out.format("[%s] HttpLogMonitor started\n", formattedTime(df));
        System.out.format("[%s] Please press CTRL-C at anytime to end the " +
                "program\n", formattedTime(df));

        while (true) {
            System.out.format("[%s] Analyzing log\n", formattedTime(df));
            m.analyze(Calendar.getInstance());
            Section[] topHits = m.mostHits(5);
            if (topHits.length == 0)
                System.out.format("[%s] No traffic to report\n", 
                        formattedTime(df));
            else {
                System.out.format("[%s] Top hits:\n", formattedTime(df));
                m.printMostHits(topHits);
            }
            String htAlert = m.highTrafficAlert();
            if (htAlert.length() > 0)
                System.out.format("[%s] %s\n", formattedTime(df), htAlert);
            String recAlert = m.recoveryAlert();
            if (recAlert.length() > 0)
                System.out.format("[%s] %s\n", formattedTime(df), recAlert);
            System.out.format("[%s] Next log analysis in %s seconds \n"
                    , formattedTime(df), sleep);
            try {
                Thread.sleep(sleep*1000);
            } catch (InterruptedException ex) {
                System.out.format("[%s] Pause interrupted...\n",
                        formattedTime(df));
            }
        }
        
    }

    public static String formattedTime(SimpleDateFormat df) {
        return df.format(Calendar.getInstance().getTime());
    }
}
