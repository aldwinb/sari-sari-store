package com.live.datadog;

import java.util.*;

public class TrafficWindow {
    Calendar time;
    Map<String, Integer> uriHits;
    public int hashCode() {
        return time.hashCode();
    }
}
