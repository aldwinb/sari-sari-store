package com.live.datadog;

public class Section {
    public int hits;
    public String uri;
    public Section(String uri, int hits) {
        this.uri = uri;
        this.hits = hits;
    }
    public int hashCode() {
        return uri.hashCode();
    }
}
